<?php

/* -AFTERLOGIC LICENSE HEADER- */

	$this->SetConf('WebMail/AllowUsersAddNewAccounts', false);
	$this->SetConf('WebMail/AllowOpenPGP', false);
	$this->SetConf('Calendar/AllowCalendar', false);
	$this->SetConf('Files/AllowFiles', false);
	$this->SetConf('Helpdesk/AllowHelpdesk', false);
	$this->SetConf('Contacts/GlobalAddressBookVisibility', EContactsGABVisibility::Off);	

	
